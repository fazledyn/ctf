from application.main import app

app.run(host='0.0.0.0', debug=True, port=1337)